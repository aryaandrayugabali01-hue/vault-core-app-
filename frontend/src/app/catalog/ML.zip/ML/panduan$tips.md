PANDUAN BELI & TIPS

Akun Mobile Legends | Vault Core

Ikuti panduan berikut setelah menerima akun Mobile Legends untuk mengamankan akses dan memastikan akun berada di bawah kendali Anda.

1. Login dan Periksa Akun

1. Buka game Mobile Legends.
2. Masuk ke Profile → Account → Switch Account.
3. Login menggunakan metode dan informasi akun yang diberikan.
4. Periksa ID, nickname, server, dan detail akun sesuai pesanan.

2. Amankan Email

Apabila akun terhubung dengan Gmail atau email lainnya:

- Ganti password email.
- Perbarui email pemulihan.
- Perbarui nomor HP pemulihan.
- Aktifkan verifikasi dua langkah (2FA).

Kelola perangkat Gmail:

1. Buka https://myaccount.google.com
2. Pilih Security → Your Devices.
3. Periksa perangkat yang terhubung.
4. Keluarkan perangkat yang bukan milik Anda melalui opsi Sign Out.

3. Bind Akun Mobile Legends

1. Buka Profile → Account.
2. Pilih metode Bind yang tersedia.
3. Hubungkan akun dengan Moonton, Facebook, Google, atau VK milik pribadi.
4. Pastikan informasi login berada di bawah kendali Anda.

4. Amankan Perangkat dan Akun Tertaut

Device Management:

1. Buka Profile → Account Settings → Account Center.
2. Pilih Device Management.
3. Periksa perangkat yang terhubung.
4. Gunakan Log Out All apabila tersedia untuk mengakhiri sesi perangkat lain.

Disconnect 3rd Party Account:

1. Masuk ke Account Center.
2. Pilih Disconnect 3rd Party Account.
3. Pilih akun pihak ketiga yang ingin dilepaskan.
4. Ikuti proses verifikasi dan konfirmasi.

Pastikan akun pribadi Anda tetap terhubung dan dapat digunakan untuk login.

5. Selesaikan Pesanan

Setelah pemeriksaan dan pengamanan akun selesai:

1. Pastikan akun sesuai dengan pesanan.
2. Pastikan akses email dan metode pemulihan telah diamankan.
3. Pastikan perangkat lama tidak lagi memiliki akses.
4. Buka Riwayat Pembelian di Vault Core.
5. Klik Selesai untuk menyelesaikan pesanan.

6. Garansi Anti Hackback Vault Core

<badge color="success">Garansi 14 Hari Kalender</badge>

Seluruh produk akun digital Vault Core mendapatkan Garansi Anti Hackback secara otomatis.

- Garansi aktif sejak pesanan dinyatakan selesai atau diterima.
- Apabila mengalami indikasi hackback, segera hubungi Admin Vault Core.
- Sertakan kronologi kejadian dan bukti pendukung.
- Klaim akan diperiksa dan diverifikasi oleh tim Vault Core.
- Apabila klaim terbukti valid, pembeli berhak mendapatkan pengembalian dana 100% dari nilai transaksi.
- Waktu pemrosesan klaim maksimal 48 jam sejak laporan dan bukti pendukung diterima.
- Klaim wajib diajukan selama masa garansi masih aktif.

PENTING: Simpan bukti transaksi dan informasi pendukung selama masa garansi berlangsung.

Butuh Bantuan?

Apabila mengalami kendala saat login, Bind, pengamanan akun, atau menemukan indikasi hackback, segera hubungi Admin Vault Core melalui kanal dukungan resmi.

VAULT CORE — Your Digital Assets, Your Confidence.