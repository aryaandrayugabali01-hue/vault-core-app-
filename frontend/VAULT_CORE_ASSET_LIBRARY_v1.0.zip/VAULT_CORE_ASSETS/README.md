# VAULT CORE — Asset Library v1.0

Paket visual mandiri untuk proyek VAULT CORE. Semua ilustrasi kategori dan UI dibuat sebagai artwork generik orisinal; tidak menggunakan logo resmi, karakter resmi, atau artwork game pihak ketiga.

## Isi paket

| Folder | Konten |
|---|---|
| `01-brand` | Logo mark, logo horizontal, favicon, ikon PWA |
| `02-hero` | Background hero WebP/JPG, GIF loop, animated WebP |
| `03-categories` | Ikon MLBB, Roblox, Free Fire, Genshin Impact, dan kategori lainnya |
| `04-tiers` | Badge Silver, Gold, Platinum |
| `05-states` | Katalog kosong, pesanan kosong, pembayaran, pengiriman, refund, error, support |
| `06-icons` | Ikon navigasi dan ikon umum dalam SVG/PNG |
| `07-backgrounds` | Neon orbit, hex grid, dan neon wave |
| `08-application` | Splash screen dan placeholder produk |
| `09-social` | OG image 1200 × 630 untuk preview tautan |

## Format dan ukuran

- SVG: source vector, skalabel dan cocok untuk web.
- PNG: raster transparan, disediakan pada resolusi 512 px sampai 1024 px atau ukuran banner yang sesuai.
- WebP: gambar web terkompresi.
- GIF: hero loop 6-frame.
- Animated WebP: versi animasi yang lebih efisien untuk browser modern.
- JPG: varian fallback untuk sistem yang tidak mendukung WebP.

## Pemasangan ke aplikasi

Salin folder aset ke `frontend/public/assets/`, sehingga path publik menjadi `/assets/...`.

Contoh:
```jsx
<img src="/assets/03-categories/category-mlbb.svg" alt="Kategori MLBB" />
```

Hero background:
```css
.hero {
  background-image:
    linear-gradient(90deg, rgba(5, 9, 20, .92), rgba(5, 9, 20, .12)),
    url('/assets/02-hero/hero-vaultcore.webp');
  background-size: cover;
  background-position: center;
}
```

Animasi hero (gunakan fallback statis bila reduced motion aktif):
```html
<picture>
  <source srcset="/assets/02-hero/hero-vaultcore-loop.webp" type="image/webp">
  <img src="/assets/02-hero/hero-vaultcore.jpg" alt="" />
</picture>
```

Untuk kebutuhan aksesibilitas, dekorasi latar sebaiknya memakai `alt=""`; ikon informatif perlu label sesuai fungsinya.

## Catatan integrasi

Paket ini berisi file aset saja. Aset belum dipasang atau dihubungkan ke komponen produksi. Beberapa bagian UI saat ini memakai ikon SVG inline dan belum memiliki slot image, sehingga integrasi perlu dilakukan terpisah pada komponen yang sesuai.

Data harga, stok, nama produk, waktu pemenuhan, garansi, refund, dan klaim layanan tidak ditanamkan ke gambar. Tampilkan data tersebut melalui sumber aplikasi yang aktual.

## Kualitas

SVG disediakan sebagai master vector. PNG/WebP adalah turunan optimasi; pilih SVG untuk ikon dan ilustrasi transparan, WebP untuk gambar besar, dan GIF/animated WebP hanya pada area yang memang memerlukan gerakan.
